const posts = [
    {
        username: "Jone Thomas",
        title: "I'm creating first post!",
        likes: [
            {
                username: "Aleem",
                createdAt: "2022-06-15T21:37:17.861Z"
            }
        ],
        location: "OH, USA",
        createdAt: "2022-06-15T21:35:42.420Z",
        comments: [
            {
                username: "Aleem",
                proffession: "Software Developer",
                title: "I like development",
                createdAt: "2022-06-15T21:37:17.861Z"
            }
        ]
    }
]



export default posts;