const initPost = {
    username: "Jone Thomas",
    title: "",
    likes: [],
    location: "OH, USA",
    createdAt: "2022-06-15T21:35:42.420Z",
    comments: []
}

const states = { initPost }

export default states;