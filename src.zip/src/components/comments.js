import React, { useState, useEffect } from 'react';
import avatar from '../assets/avatar.png';
import likeIco from '../assets/Like.png';
import deleteIco from '../assets/Deletes.png';
import editIco from '../assets/Edit.png';
import "./Style.css";

const Comment = ({ comment }) => {

    return (
        <div className='d-flex p-3'>
            <div className='pt-3 user_img_comment'>
                <img className='w-50' src={avatar} />
            </div>
            <div className='comment_box'>
                <div className='d-flex justify-content-between' >
                    <p className='mb-0 comment_Uname'> {comment.username} </p>
                    <p className='mb-0 comment_time'> {comment.createdAt} </p>
                </div>
                <div>
                    <p className='mb-0 comment_prof'> {comment.proffession}</p>
                    <p className='mb-0 comment_title'> {comment.title}</p>
                </div>
                <div className='d-flex pt-2' >
                    <p className='mb-0 comment_mesg_like'> 0 Likes  </p>
                    <p className='mb-0 feedback_ico'> <img style={{ width: 20 }} src={likeIco} /> Likes  </p>
                    <p className='mb-0 feedback_ico'> <img style={{ width: 20 }} src={editIco} /> Edit  </p>
                    <p className='mb-0 feedback_ico'> <img style={{ width: 20 }} src={deleteIco} /> Delete  </p>
                </div>
            </div>
        </div>
    )
}

const PostCompoment = (props) => {
    const [comments, setComments] = useState([]);
    const [commentTitle, setCommentTitle] = useState()

    useEffect(() => {
        if (props.commentList) {
            setComments(props.commentList)
        }
    }, []);

    const onChangeAddComment = (e) => {
        setCommentTitle(e.target.value)
    }

    return (
        <div>
            <div className='d-flex p-3'>
                <div className='pt-3 user_img_comment'>
                    <img className='w-50' src={avatar} />
                </div>
                <div className='pl-3 pt-1 comment_section'>
                    <input className='comment_input' onChange={onChangeAddComment} placeholder='Add a Comment' type="text" />
                </div>
            </div>
            {
                comments.map((comment, i) => <Comment comment={comment} key={i} />)
            }

        </div>
    )
}

export default PostCompoment